import json
import logging
import re
import uuid
from datetime import datetime, timezone

from mysql.connector.cursor import MySQLCursor

from field_maps import (
    BATCH_DETAILS_FIELD_MAP,
    BATCH_INVOICE_ALLOCATION_VALUE_FIELD_MAP,
    BATCH_INVOICE_CUSTOM_FIELD_MAP,
    BATCH_INVOICE_DETAIL_FIELD_MAP,
    CHARGE_FIELD_MAP,
    DETAIL_FIELD_MAP,
    SERVICE_FIELD_MAP,
    SUMMARY_FIELD_MAP,
    map_record,
)
from secret_crypto import decrypt_secret

logger = logging.getLogger(__name__)

# interfaceconfiguration columns the tracker web app stores AES-256-GCM encrypted
# (enc:v1:...). decrypt_secret() passes plaintext values through untouched, so a
# database with a mix of tracker-written and legacy rows still loads.
_SECRET_COLUMNS = (
    "SFTP_Password",
    "SMTP_Password",
    "Platform_Password",
    "Platform_AppAuthKey",
    "Platform_DB_Password",
)

# interfaceconfiguration is a wide table (one row per interface) rather than a
# key-value one, so loading it means mapping its columns onto the dotted
# config.py keys that load_config(interface_values=...) already understands.
# Columns left NULL in the DB are skipped so appsettings.yml keeps supplying
# the default for anything not yet configured for a given interface.
_STRING_COLUMN_KEY_MAP = {
    "SFTP_Host": "Sftp.Host",
    "SFTP_Port": "Sftp.Port",
    "SFTP_UserName": "Sftp.Username",
    "SFTP_Password": "Sftp.Password",
    "SFTP_RemoteDirectory": "Sftp.RemoteDirectory",
    "SMTP_Host": "Email.Smtp.Host",
    "SMTP_Port": "Email.Smtp.Port",
    "SMTP_UserId": "Email.Smtp.Username",
    "SMTP_Password": "Email.Smtp.Password",
    "Platform_InstanceUrl": "InvoiceApi.BaseUri",
    "Platform_UserId": "InvoiceApi.Authentication.LoginUserName",
    "Platform_Password": "InvoiceApi.Authentication.Password",
    "Platform_AppAuthKey": "InvoiceApi.Authentication.ClientApiKey",
    "Email_Sender_Email": "Email.Sender.Email",
    "Email_Sender_Name": "Email.Sender.Name",
    "Email_Subject": "Email.Subject",
    "Email_Body": "Email.Body",
    "Email_Attachment_FileName": "Email.Attachment.FileName",
    "Failure_Subject": "Email.FailureNotification.Subject",
    "Failure_Body": "Email.FailureNotification.Body",
    "Output_Directory": "Output.Folder",
    # Replaces the old hardcoded Jobs.CBTS_AP.OutputPrefix lookup: whichever
    # interface is running gets its own name as the output filename prefix,
    # with no per-interface config needed.
    "InterfaceName": "Job.OutputPrefix",
}
_BOOLEAN_COLUMN_KEY_MAP = {
    "SMTP_UseTLS": "Email.Smtp.UseTls",
    "Email_Enabled": "Email.Enabled",
    "Email_Attachment_Enabled": "Email.Attachment.Enabled",
    "Failure_Notification_Enabled": "Email.FailureNotification.Enabled",
}
_LIST_COLUMN_KEY_MAP = {
    "Email_Recipients_To": "Email.Recipients.To",
    "Email_Recipients_Cc": "Email.Recipients.Cc",
    "Failure_Recipients_To": "Email.FailureNotification.Recipients.To",
    "Failure_Recipients_Cc": "Email.FailureNotification.Recipients.Cc",
}


def _parse_recipient_list(value: str) -> list:
    value = value.strip()
    if not value:
        return []
    if value.startswith("["):
        try:
            return json.loads(value)
        except ValueError:
            pass
    return [item.strip() for item in re.split(r"[,;]", value) if item.strip()]


def load_interface_configuration(cursor: MySQLCursor, interface_id: int) -> dict:
    cursor.execute(
        "SELECT * FROM interfaceconfiguration WHERE InterfaceId = %s AND IsActive = 1",
        (interface_id,),
    )
    row = cursor.fetchone()
    if row is None:
        logger.error(
            "No active interfaceconfiguration row for InterfaceId=%s (either it doesn't "
            "exist, or IsActive=0)",
            interface_id,
        )
        raise ValueError(f"No active interfaceconfiguration row for InterfaceId={interface_id}")
    if not isinstance(row, dict):
        columns = [d[0] for d in cursor.description]
        row = dict(zip(columns, row))

    for column in _SECRET_COLUMNS:
        if row.get(column):
            try:
                row[column] = decrypt_secret(row[column])
            except Exception:
                logger.exception(
                    "Could not decrypt interfaceconfiguration.%s for InterfaceId=%s -- "
                    "check INTERFACE_SECRET_KEY matches the tracker backend",
                    column,
                    interface_id,
                )
                raise

    values = {}
    for column, dotted_key in _STRING_COLUMN_KEY_MAP.items():
        value = row.get(column)
        if value not in (None, ""):
            values[dotted_key] = value
    for column, dotted_key in _BOOLEAN_COLUMN_KEY_MAP.items():
        value = row.get(column)
        if value is not None:
            values[dotted_key] = bool(value)
    for column, dotted_key in _LIST_COLUMN_KEY_MAP.items():
        value = row.get(column)
        if value:
            values[dotted_key] = _parse_recipient_list(value)
    logger.debug(
        "interfaceconfiguration InterfaceId=%s: resolved %d overlay key(s): %s",
        interface_id,
        len(values),
        sorted(values.keys()),
    )
    return values


def get_open_payment_files(cursor: MySQLCursor, interface_id: int) -> list:
    cursor.execute(
        """
        SELECT id, ap_batch_name, ap_batch_payment_file_id, interface_id, ap_batch_status
        FROM ap_payment_file_details
        WHERE interface_id = %s AND ap_batch_status = 'New'
        """,
        (interface_id,),
    )
    rows = cursor.fetchall()
    logger.debug(
        "ap_payment_file_details: %d row(s) with ap_batch_status='New' for interface_id=%s",
        len(rows),
        interface_id,
    )
    return rows


def insert_payment_file(
    cursor: MySQLCursor, interface_id: int, payment_file_id, batch_name: str, record: dict
) -> int:
    """Inserts one ap_payment_file_details row for a batch just pulled from
    the Get Payment Batches API -- both the pipeline-owned tracking columns
    (ap_batch_status/processed_date/log_id) and the raw API metadata
    (client, ap_payment_file_status, amounts, etc., via BATCH_DETAILS_FIELD_MAP)
    live on this single row (formerly split into a separate ap_batch_details
    table -- merged since it was always a 1:1 shadow, never queried alone)."""
    data = map_record(record, BATCH_DETAILS_FIELD_MAP)
    data["ap_batch_name"] = batch_name
    data["ap_batch_payment_file_id"] = payment_file_id
    data["interface_id"] = interface_id
    data["ap_batch_status"] = "New"
    payment_file_detail_id = insert(cursor, "ap_payment_file_details", data)
    logger.debug(
        "ap_payment_file_details: inserted id=%s for paymentFileId=%s (interface_id=%s)",
        payment_file_detail_id,
        payment_file_id,
        interface_id,
    )
    return payment_file_detail_id


def insert_ap_invoice(cursor: MySQLCursor, payment_file_detail_id: int, invoice_number: str) -> int:
    data = {
        "ap_invoice_number": invoice_number,
        "ap_paymentfile_id": payment_file_detail_id,
    }
    result = insert(cursor, "ap_invoices", data)
    logger.debug("insert_ap_invoice: success (ap_invoice_id=%s)", result)
    return result


def insert_batch_invoice_detail(
    cursor: MySQLCursor, payment_file_detail_id: int, batch_name: str, detail_record: dict
) -> int:
    """Persist one invoiceAPBatchDetails[] entry from the Get Invoice List API
    response into ap_batch_invoice_details (flat fields only -- its nested
    allocationValues[]/custom[] arrays are stored as child rows, see
    insert_batch_invoice_allocation_value / insert_batch_invoice_custom)."""
    data = map_record(detail_record, BATCH_INVOICE_DETAIL_FIELD_MAP)
    data["ap_payment_file_detail_id"] = payment_file_detail_id
    data["ap_batch_name"] = batch_name
    result = insert(cursor, "ap_batch_invoice_details", data)
    logger.debug("insert_batch_invoice_detail: success (id=%s)", result)
    return result


def insert_batch_invoice_allocation_value(
    cursor: MySQLCursor, batch_invoice_detail_id: int, allocation_record: dict
) -> int:
    data = map_record(allocation_record, BATCH_INVOICE_ALLOCATION_VALUE_FIELD_MAP)
    data["batch_invoice_detail_id"] = batch_invoice_detail_id
    result = insert(cursor, "ap_batch_invoice_allocation_values", data)
    logger.debug("insert_batch_invoice_allocation_value: success (id=%s)", result)
    return result


def insert_batch_invoice_custom(
    cursor: MySQLCursor, batch_invoice_detail_id: int, custom_record: dict
) -> int:
    data = map_record(custom_record, BATCH_INVOICE_CUSTOM_FIELD_MAP)
    data["batch_invoice_detail_id"] = batch_invoice_detail_id
    result = insert(cursor, "ap_batch_invoice_custom", data)
    logger.debug("insert_batch_invoice_custom: success (id=%s)", result)
    return result


def get_invoice_numbers_for_payment_file(cursor: MySQLCursor, payment_file_detail_id: int) -> list:
    cursor.execute(
        """
        SELECT DISTINCT ap_invoice_number
        FROM ap_invoices
        WHERE ap_paymentfile_id = %s AND ap_invoice_number IS NOT NULL
        """,
        (payment_file_detail_id,),
    )
    rows = cursor.fetchall()
    invoice_numbers = [row["ap_invoice_number"] if isinstance(row, dict) else row[0] for row in rows]
    logger.debug(
        "ap_invoices: %d invoice number(s) found for ap_paymentfile_id=%s",
        len(invoice_numbers),
        payment_file_detail_id,
    )
    return invoice_numbers


def start_batch_run(cursor: MySQLCursor, payment_file_detail_id: int) -> str:
    """Generates a fresh run UUID and records it directly on
    ap_payment_file_details before any invoice is processed -- replaces the
    old ap_invoices_process_log table (formerly one row per run; merged in
    since a batch is only ever processed by one run at a time, and the
    tracker's own Run Logs history feature was retired alongside it)."""
    process_uuid = str(uuid.uuid4())
    cursor.execute(
        "UPDATE ap_payment_file_details SET invoice_process_uuid = %s WHERE id = %s",
        (process_uuid, payment_file_detail_id),
    )
    logger.debug(
        "ap_payment_file_details id=%s: invoice_process_uuid set to %s",
        payment_file_detail_id,
        process_uuid,
    )
    return process_uuid


def update_payment_file_status(
    cursor: MySQLCursor, payment_file_detail_id: int, status: str
) -> None:
    cursor.execute(
        """
        UPDATE ap_payment_file_details
        SET ap_batch_status = %s, processed_date = %s
        WHERE id = %s
        """,
        (status, datetime.now(timezone.utc).replace(tzinfo=None), payment_file_detail_id),
    )
    logger.debug(
        "ap_payment_file_details id=%s: ap_batch_status set to '%s'",
        payment_file_detail_id,
        status,
    )


def upsert(cursor: MySQLCursor, table: str, data: dict, unique_cols=None) -> int:
    unique_cols = unique_cols or []
    columns = list(data.keys())
    col_list = ", ".join(f"`{c}`" for c in columns)
    placeholders = ", ".join(["%s"] * len(columns))
    update_cols = [c for c in columns if c not in unique_cols]
    sql = f"INSERT INTO `{table}` ({col_list}) VALUES ({placeholders})"
    if update_cols:
        update_clause = ", ".join(f"`{c}`=VALUES(`{c}`)" for c in update_cols)
        sql += f" ON DUPLICATE KEY UPDATE {update_clause}"
    cursor.execute(sql, list(data.values()))
    return cursor.lastrowid


def insert(cursor: MySQLCursor, table: str, data: dict) -> int:
    columns = list(data.keys())
    col_list = ", ".join(f"`{c}`" for c in columns)
    placeholders = ", ".join(["%s"] * len(columns))
    sql = f"INSERT INTO `{table}` ({col_list}) VALUES ({placeholders})"
    cursor.execute(sql, list(data.values()))
    return cursor.lastrowid


def insert_response_log(
    cursor: MySQLCursor,
    invoice_number: str,
    request_url: str,
    http_status_code: int,
    is_success: bool,
    response_message: str,
    response_body,
    error_message: str = None,
    invoice_process_uuid: str = None,
) -> int:
    data = {
        "invoice_number": invoice_number,
        "request_url": request_url,
        "http_status_code": http_status_code,
        "is_success": 1 if is_success else 0,
        "response_message": response_message,
        "response_body": json.dumps(response_body) if response_body is not None else None,
        "error_message": error_message,
        "created_datetime": datetime.now(timezone.utc).replace(tzinfo=None),
        "invoice_process_uuid": invoice_process_uuid,
    }
    result = insert(cursor, "invoice_response_log", data)
    logger.debug("insert_response_log: success (log_id=%s)", result)
    return result


def upsert_invoice_summary(
    cursor: MySQLCursor,
    record: dict,
    log_id: int,
    invoice_process_uuid: str,
    ap_payment_file_detail_id: int,
) -> int:
    data = map_record(record, SUMMARY_FIELD_MAP)
    data["log_id"] = log_id
    data["invoice_process_uuid"] = invoice_process_uuid
    data["ap_payment_file_detail_id"] = ap_payment_file_detail_id
    result = upsert(cursor, "invoice_summary", data, unique_cols=["invoice_id"])
    logger.debug("upsert_invoice_summary: success (invoice_id=%s)", data.get("invoice_id"))
    return result


def upsert_invoice_detail(cursor: MySQLCursor, record: dict, log_id: int) -> int:
    data = map_record(record, DETAIL_FIELD_MAP)
    data["log_id"] = log_id
    result = upsert(cursor, "invoice_detail", data, unique_cols=["invoice_id"])
    logger.debug("upsert_invoice_detail: success (detail_id=%s)", result)
    return result


def insert_invoice_line_detail(cursor: MySQLCursor, detail_id: int, service_total_count) -> int:
    data = {
        "detail_id": detail_id,
        "service_total_count": service_total_count,
    }
    result = insert(cursor, "invoice_line_detail", data)
    logger.debug("insert_invoice_line_detail: success (line_detail_id=%s)", result)
    return result


def insert_invoice_service(cursor: MySQLCursor, line_detail_id: int, service_record: dict) -> int:
    data = map_record(service_record, SERVICE_FIELD_MAP)
    data["line_detail_id"] = line_detail_id
    result = insert(cursor, "invoice_service", data)
    logger.debug("insert_invoice_service: success (service_pk=%s)", result)
    return result


def insert_invoice_charge(cursor: MySQLCursor, service_pk: int, charge_record: dict) -> int:
    data = map_record(charge_record, CHARGE_FIELD_MAP)
    data["service_pk"] = service_pk
    result = insert(cursor, "invoice_charge", data)
    logger.debug("insert_invoice_charge: success (id=%s)", result)
    return result


def update_ap_invoice_status(
    cursor: MySQLCursor,
    invoice_number: str,
    api_status: str,
    response_obj,
    response_status_code: int,
) -> None:
    sql = """
        UPDATE ap_invoices
        SET ap_invoice_api_status = %s,
            api_response_obj = %s,
            api_response_status_code = %s
        WHERE ap_invoice_number = %s
    """
    cursor.execute(
        sql,
        (
            api_status,
            json.dumps(response_obj) if response_obj is not None else None,
            response_status_code,
            invoice_number,
        ),
    )
    logger.debug(
        "update_ap_invoice_status: success (invoice_number=%s, api_status=%s)",
        invoice_number,
        api_status,
    )


def store_invoice_record(
    cursor: MySQLCursor,
    record: dict,
    log_id: int,
    invoice_process_uuid: str,
    ap_payment_file_detail_id: int,
) -> None:
    logger.debug("store_invoice_record: in process")
    invoice_id = upsert_invoice_summary(
        cursor, record, log_id, invoice_process_uuid, ap_payment_file_detail_id
    )
    detail_id = upsert_invoice_detail(cursor, record, log_id)

    # clear previously stored nested rows for this invoice so re-processing doesn't duplicate them
    # (invoice_service / invoice_charge cascade-delete via FK)
    cursor.execute("DELETE FROM invoice_line_detail WHERE detail_id = %s", (detail_id,))

    for line_detail in record.get("invoiceDetails", []) or []:
        line_detail_id = insert_invoice_line_detail(
            cursor, detail_id, line_detail.get("serviceTotalCount")
        )
        for service_record in line_detail.get("invoiceServices", []) or []:
            service_pk = insert_invoice_service(cursor, line_detail_id, service_record)
            for charge_record in service_record.get("invoiceCharges", []) or []:
                insert_invoice_charge(cursor, service_pk, charge_record)

    logger.debug("store_invoice_record: success (invoice_id=%s)", invoice_id)
